"use client"

import FemaleCyclingCoachLandingPage from "../page"

export default function SyntheticV0PageForDeployment() {
  return <FemaleCyclingCoachLandingPage />
}